package de.fu_berlin.inf.ag_se.browser.html;

import java.util.Map;

/**
 * Abstractions of an HTML tag like &lt;a
 * href=&quot;http://bkahlert.com&quot;&gt;bkahlert.com&lt;/a&gt;.
 * 
 * @author bkahlert
 * 
 */
public interface IElement {

	/**
	 * Returns the HTML tag's name.
	 * 
	 * @return
	 */
	public String getName();

	public Map<String, String> getAttributes();

	/**
	 * Returns the attribute with the given name.
	 * 
	 * @param name
	 * @return null if attribute is not set
	 */
	public String getAttribute(String name);

	String getData(String key);

	/**
	 * Returns the {@link IElement}'s css classes.
	 * 
	 * @return
	 */
	public String[] getClasses();

	/**
	 * Returns the {@link IElement}'s content, which is the portion between the
	 * opening and closing tag.
	 * 
	 * @return
	 */
	public String getContent();

	/**
	 * Returns html that represents this {@link IElement}.
	 * 
	 * @return
	 */
	public String toHtml();

}
