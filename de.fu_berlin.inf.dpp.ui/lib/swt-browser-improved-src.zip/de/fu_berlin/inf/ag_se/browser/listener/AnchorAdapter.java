package de.fu_berlin.inf.ag_se.browser.listener;

import de.fu_berlin.inf.ag_se.browser.html.IAnchor;

public class AnchorAdapter implements IAnchorListener {

	@Override
	public void anchorHovered(IAnchor anchor, boolean entered) {
		return;
	}

}
