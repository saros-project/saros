package de.fu_berlin.inf.ag_se.browser.listener;

import java.net.URI;

public class URIAdapter implements IURIListener {

	@Override
	public void uriHovered(URI uri, boolean entered) {
		return;
	}

}
