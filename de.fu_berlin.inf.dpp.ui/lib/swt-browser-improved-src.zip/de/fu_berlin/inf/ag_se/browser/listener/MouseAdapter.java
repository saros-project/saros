package de.fu_berlin.inf.ag_se.browser.listener;

import de.fu_berlin.inf.ag_se.browser.html.IElement;

public class MouseAdapter implements IMouseListener {

	@Override
	public void mouseMove(double x, double y) {
	}

	@Override
	public void mouseDown(double x, double y, IElement element) {
	}

	@Override
	public void mouseUp(double x, double y, IElement element) {
	}

	@Override
	public void clicked(double x, double y, IElement element) {
	}

}
