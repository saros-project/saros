package de.fu_berlin.inf.ag_se.browser.extensions;


public interface IBootstrapBrowser extends IJQueryBrowser {

}