package de.fu_berlin.inf.ag_se.browser.functions;

public interface Function<V> {
    void run(V input);
}
